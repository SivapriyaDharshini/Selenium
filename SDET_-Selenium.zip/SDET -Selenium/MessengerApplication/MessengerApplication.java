package MessengerApplication;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class MessengerApplication{
    	public static void main(String[] args) throws InterruptedException {
      	System.setProperty("webdriver.chrome.driver", "C:/max/chromedriver.exe");

      	WebDriver driver = new ChromeDriver();
      	driver.get("http://Messenger.com/login/");
      	driver.manage().window().maximize();
      	driver.findElement(By.name("email")).sendKeys("karthikeyanmtv@gmail.com");
      	driver.findElement(By.name("pass")).sendKeys("Password");
      	driver.findElement(By.id("loginbutton")).click();
      	driver.findElement(By.name("messages")).click();
      	//wait 20 seconds 
    	WebDriverWait wait = new WebDriverWait(driver, 20);
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("u_0_5")));
    	driver.findElement(By.id("u_0_5")).click();
    	
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='inputtext textInput']")));
    	
    	WebElement friendName = driver.findElement(By.xpath("//input[@class='inputtext textInput']"));
    	friendName.sendKeys("Ram");
    	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//li[@class='user selected']")));
    	friendName.sendKeys(Keys.ENTER);

    	WebElement messageBox = driver.findElement(By.xpath("//textarea[@class='uiTextareaAutogrow _552m']"));
    	wait.until(ExpectedConditions.visibilityOf(messageBox));
    	messageBox.sendKeys("Good Morning");

    	messageBox.sendKeys(Keys.ENTER);

	}
}
